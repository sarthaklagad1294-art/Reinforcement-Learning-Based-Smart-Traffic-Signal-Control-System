/**
 * Smart Traffic Signal RL // High-Fidelity Canvas Rendering & Telemetry Client
 */

// State management
let simState = null;
let isPlaying = false;
let playbackSpeed = 4;
let timerId = null;
let currentController = "RL (DQN)";

// Canvas & Contexts
const trafficCanvas = document.getElementById("trafficCanvas");
const ctx = trafficCanvas.getContext("2d");

const chartQueueCanvas = document.getElementById("chartQueue");
const ctxQueue = chartQueueCanvas.getContext("2d");

const chartRewardCanvas = document.getElementById("chartReward");
const ctxReward = chartRewardCanvas.getContext("2d");

// DOM Elements
const btnPlayPause = document.getElementById("btnPlayPause");
const playIcon = document.getElementById("playIcon");
const playText = document.getElementById("playText");
const btnStep = document.getElementById("btnStep");
const btnReset = document.getElementById("btnReset");
const speedSelect = document.getElementById("speedSelect");
const rushHourToggle = document.getElementById("rushHourToggle");
const activeControllerBadge = document.getElementById("active-controller-badge");
const simStepBadge = document.getElementById("sim-step-badge");
const phaseTitle = document.getElementById("phaseTitle");
const phaseTimer = document.getElementById("phaseTimer");
const manualActions = document.getElementById("manualActions");
const btnManualNS = document.getElementById("btnManualNS");
const btnManualEW = document.getElementById("btnManualEW");

// Metrics elements
const metricThroughput = document.getElementById("metricThroughput");
const metricDelay = document.getElementById("metricDelay");
const metricQueue = document.getElementById("metricQueue");
const metricReward = document.getElementById("metricReward");
const barN = document.getElementById("barN");
const barS = document.getElementById("barS");
const barE = document.getElementById("barE");
const barW = document.getElementById("barW");
const countN = document.getElementById("countN");
const countS = document.getElementById("countS");
const countE = document.getElementById("countE");
const countW = document.getElementById("countW");

// Controller Tabs
const ctrlTabs = document.querySelectorAll(".ctrl-tab");

// High-DPI canvas setup
function setupHiDPI(canvas, context) {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  context.scale(dpr, dpr);
}

// -------------------------------------------------------------
// API Communication
// -------------------------------------------------------------
async function fetchState() {
  try {
    const res = await fetch("/api/state");
    simState = await res.json();
    updateUI();
  } catch (err) {
    console.error("Failed to fetch state:", err);
  }
}

async function stepSimulation(manualAction = null) {
  try {
    const res = await fetch("/api/step", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ steps: 1, manual_action: manualAction }),
    });
    simState = await res.json();
    updateUI();
  } catch (err) {
    console.error("Failed to step simulation:", err);
  }
}

async function resetSimulation() {
  try {
    const isRush = rushHourToggle.checked;
    const res = await fetch("/api/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rush_hour: isRush }),
    });
    simState = await res.json();
    updateUI();
  } catch (err) {
    console.error("Failed to reset:", err);
  }
}

async function setControllerMode(mode) {
  try {
    const res = await fetch("/api/set-controller", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode }),
    });
    const data = await res.json();
    currentController = data.mode;
    activeControllerBadge.textContent = `CONTROLLER: ${currentController}`;

    ctrlTabs.forEach((tab) => {
      tab.classList.toggle("active", tab.dataset.mode === currentController);
    });

    manualActions.style.display = currentController === "Manual" ? "flex" : "none";
  } catch (err) {
    console.error("Failed to set controller:", err);
  }
}

// -------------------------------------------------------------
// UI Updates
// -------------------------------------------------------------
function updateUI() {
  if (!simState) return;

  // Header badges
  const totalSec = simState.step || 0;
  const mins = String(Math.floor(totalSec / 60)).padStart(2, "0");
  const secs = String(totalSec % 60).padStart(2, "0");
  simStepBadge.textContent = `T: ${mins}:${secs} (Step ${simState.step})`;

  // Phase overlay
  const pName = simState.phase_name || "NS_GREEN";
  phaseTitle.textContent = pName.replace("_", " ");
  if (pName.includes("GREEN")) {
    phaseTitle.style.color = "#10b981";
  } else if (pName.includes("YELLOW")) {
    phaseTitle.style.color = "#f59e0b";
  } else {
    phaseTitle.style.color = "#ef4444";
  }
  phaseTimer.textContent = `Elapsed: ${simState.phase_elapsed_time}s ${simState.is_transitioning ? "(Switching...)" : ""}`;

  // Metrics
  metricThroughput.textContent = simState.throughput_total || 0;
  metricDelay.innerHTML = `${simState.avg_cleared_delay || 0.0}<span class="unit">s</span>`;
  
  const queues = simState.queue_lengths || { N: 0, S: 0, E: 0, W: 0 };
  const totalQ = (queues.N || 0) + (queues.S || 0) + (queues.E || 0) + (queues.W || 0);
  metricQueue.textContent = totalQ;
  metricReward.textContent = (simState.episode_reward || 0.0).toFixed(1);

  // Approach bars (max ~20 cars per approach)
  const maxCap = 20;
  countN.textContent = queues.N || 0;
  countS.textContent = queues.S || 0;
  countE.textContent = queues.E || 0;
  countW.textContent = queues.W || 0;

  barN.style.width = `${Math.min(100, ((queues.N || 0) / maxCap) * 100)}%`;
  barS.style.width = `${Math.min(100, ((queues.S || 0) / maxCap) * 100)}%`;
  barE.style.width = `${Math.min(100, ((queues.E || 0) / maxCap) * 100)}%`;
  barW.style.width = `${Math.min(100, ((queues.W || 0) / maxCap) * 100)}%`;

  // Draw Canvases
  renderIntersection();
  renderMiniChart(ctxQueue, chartQueueCanvas, simState.history?.queues || [], "#f59e0b", "Queue");
  renderMiniChart(ctxReward, chartRewardCanvas, simState.history?.rewards || [], "#10b981", "Reward");
}

// -------------------------------------------------------------
// Canvas Drawing: Intersection Simulation
// -------------------------------------------------------------
function renderIntersection() {
  const w = trafficCanvas.width;
  const h = trafficCanvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const roadWidth = 140; // width of 4 lanes (2 incoming, 2 outgoing)
  const laneWidth = roadWidth / 4;

  ctx.clearRect(0, 0, w, h);

  // Background grass / terrain
  ctx.fillStyle = "#0c1322";
  ctx.fillRect(0, 0, w, h);

  // Asphalt roads
  ctx.fillStyle = "#1e293b";
  // Vertical road (North-South)
  ctx.fillRect(cx - roadWidth / 2, 0, roadWidth, h);
  // Horizontal road (East-West)
  ctx.fillRect(0, cy - roadWidth / 2, w, roadWidth);

  // Center intersection box
  ctx.fillStyle = "#253349";
  ctx.fillRect(cx - roadWidth / 2, cy - roadWidth / 2, roadWidth, roadWidth);

  // Lane Dividers & Markings
  ctx.strokeStyle = "#475569";
  ctx.lineWidth = 1.5;

  // Double Yellow Center Lines (Separating incoming and outgoing lanes)
  ctx.strokeStyle = "#eab308";
  ctx.lineWidth = 2;
  // Vertical Center Line
  drawDashedLine(ctx, cx, 0, cx, cy - roadWidth / 2, [0, 0]);
  drawDashedLine(ctx, cx, cy + roadWidth / 2, cx, h, [0, 0]);
  // Horizontal Center Line
  drawDashedLine(ctx, 0, cy, cx - roadWidth / 2, cy, [0, 0]);
  drawDashedLine(ctx, cx + roadWidth / 2, cy, w, cy, [0, 0]);

  // White Dashed Lane Dividers
  ctx.strokeStyle = "rgba(255, 255, 255, 0.4)";
  ctx.lineWidth = 1.5;
  // North lanes divider
  drawDashedLine(ctx, cx - laneWidth, 0, cx - laneWidth, cy - roadWidth / 2, [8, 8]);
  drawDashedLine(ctx, cx + laneWidth, 0, cx + laneWidth, cy - roadWidth / 2, [8, 8]);
  // South lanes divider
  drawDashedLine(ctx, cx - laneWidth, cy + roadWidth / 2, cx - laneWidth, h, [8, 8]);
  drawDashedLine(ctx, cx + laneWidth, cy + roadWidth / 2, cx + laneWidth, h, [8, 8]);
  // West lanes divider
  drawDashedLine(ctx, 0, cy - laneWidth, cx - roadWidth / 2, cy - laneWidth, [8, 8]);
  drawDashedLine(ctx, 0, cy + laneWidth, cx - roadWidth / 2, cy + laneWidth, [8, 8]);
  // East lanes divider
  drawDashedLine(ctx, cx + roadWidth / 2, cy - laneWidth, w, cy - laneWidth, [8, 8]);
  drawDashedLine(ctx, cx + roadWidth / 2, cy + laneWidth, w, cy + laneWidth, [8, 8]);

  // Stop lines (thick solid white)
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 4;
  // North incoming stop line (right side of center divider heading down)
  ctx.beginPath();
  ctx.moveTo(cx - roadWidth / 2, cy - roadWidth / 2);
  ctx.lineTo(cx, cy - roadWidth / 2);
  ctx.stroke();

  // South incoming stop line (heading up)
  ctx.beginPath();
  ctx.moveTo(cx, cy + roadWidth / 2);
  ctx.lineTo(cx + roadWidth / 2, cy + roadWidth / 2);
  ctx.stroke();

  // East incoming stop line (heading left)
  ctx.beginPath();
  ctx.moveTo(cx + roadWidth / 2, cy - roadWidth / 2);
  ctx.lineTo(cx + roadWidth / 2, cy);
  ctx.stroke();

  // West incoming stop line (heading right)
  ctx.beginPath();
  ctx.moveTo(cx - roadWidth / 2, cy);
  ctx.lineTo(cx - roadWidth / 2, cy + roadWidth / 2);
  ctx.stroke();

  // Draw Traffic Light Signal Pods
  const signals = simState?.signals || { N: "GREEN", S: "GREEN", E: "RED", W: "RED" };
  drawSignalLight(ctx, cx - roadWidth / 2 - 25, cy - roadWidth / 2 - 25, signals.N, "N");
  drawSignalLight(ctx, cx + roadWidth / 2 + 10, cy + roadWidth / 2 + 10, signals.S, "S");
  drawSignalLight(ctx, cx + roadWidth / 2 + 10, cy - roadWidth / 2 - 25, signals.E, "E");
  drawSignalLight(ctx, cx - roadWidth / 2 - 25, cy + roadWidth / 2 + 10, signals.W, "W");

  // Draw Vehicles
  if (simState?.vehicles) {
    const armLengthMeters = 200.0;
    const pxPerMeter = (cx - roadWidth / 2) / armLengthMeters;

    for (const car of simState.vehicles) {
      drawVehicle(ctx, car, cx, cy, roadWidth, laneWidth, pxPerMeter);
    }
  }
}

function drawDashedLine(context, x1, y1, x2, y2, dash = [5, 5]) {
  context.save();
  context.beginPath();
  context.setLineDash(dash);
  context.moveTo(x1, y1);
  context.lineTo(x2, y2);
  context.stroke();
  context.restore();
}

function drawSignalLight(context, x, y, state, label) {
  context.save();
  // Outer casing
  context.fillStyle = "#0f172a";
  context.strokeStyle = "rgba(255, 255, 255, 0.2)";
  context.lineWidth = 1;
  context.beginPath();
  context.roundRect(x, y, 22, 48, 6);
  context.fill();
  context.stroke();

  // Red, Yellow, Green LED spots
  const colors = {
    RED: state === "RED" ? "#ef4444" : "#451a1a",
    YELLOW: state === "YELLOW" ? "#f59e0b" : "#453010",
    GREEN: state === "GREEN" ? "#10b981" : "#133526",
  };

  const glows = {
    RED: state === "RED" ? "rgba(239, 68, 68, 0.7)" : "transparent",
    YELLOW: state === "YELLOW" ? "rgba(245, 158, 11, 0.7)" : "transparent",
    GREEN: state === "GREEN" ? "rgba(16, 185, 129, 0.7)" : "transparent",
  };

  // Red LED
  drawLed(context, x + 11, y + 10, colors.RED, glows.RED);
  // Yellow LED
  drawLed(context, x + 11, y + 24, colors.YELLOW, glows.YELLOW);
  // Green LED
  drawLed(context, x + 11, y + 38, colors.GREEN, glows.GREEN);

  context.restore();
}

function drawLed(context, cx, cy, color, glow) {
  context.save();
  if (glow !== "transparent") {
    context.shadowColor = glow;
    context.shadowBlur = 10;
  }
  context.fillStyle = color;
  context.beginPath();
  context.arc(cx, cy, 5, 0, Math.PI * 2);
  context.fill();
  context.restore();
}

function drawVehicle(context, car, cx, cy, roadWidth, laneWidth, pxPerMeter) {
  context.save();

  const carLengthPx = 18;
  const carWidthPx = 10;

  let x = 0;
  let y = 0;
  let angle = 0;

  // Compute (x, y) based on approach origin and position
  // position: 0 is at screen edge, 200m is at stop line (center - roadWidth/2)
  const stopLineOffset = cx - roadWidth / 2;
  const distFromStop = Math.max(-40, (200.0 - car.position) * pxPerMeter);

  if (car.origin === "N") {
    // Coming from North, moving South
    // Incoming lanes are on the left side of road from center
    const laneOffset = car.lane_idx === 0 ? -laneWidth * 1.5 : -laneWidth * 0.5;
    x = cx + laneOffset;
    y = (cy - roadWidth / 2) - distFromStop;
    angle = Math.PI / 2; // pointing down
  } else if (car.origin === "S") {
    // Coming from South, moving North
    // Incoming lanes are on the right side of road from center
    const laneOffset = car.lane_idx === 0 ? laneWidth * 0.5 : laneWidth * 1.5;
    x = cx + laneOffset;
    y = (cy + roadWidth / 2) + distFromStop;
    angle = -Math.PI / 2; // pointing up
  } else if (car.origin === "W") {
    // Coming from West, moving East
    // Incoming lanes are below center
    const laneOffset = car.lane_idx === 0 ? laneWidth * 0.5 : laneWidth * 1.5;
    x = (cx - roadWidth / 2) - distFromStop;
    y = cy + laneOffset;
    angle = 0; // pointing right
  } else if (car.origin === "E") {
    // Coming from East, moving West
    // Incoming lanes are above center
    const laneOffset = car.lane_idx === 0 ? -laneWidth * 1.5 : -laneWidth * 0.5;
    x = (cx + roadWidth / 2) + distFromStop;
    y = cy + laneOffset;
    angle = Math.PI; // pointing left
  }

  // Draw rotated vehicle chassis
  context.translate(x, y);
  context.rotate(angle);

  // Brake light indicator if stopped
  if (car.is_stopped) {
    context.fillStyle = "rgba(239, 68, 68, 0.8)";
    context.shadowColor = "#ef4444";
    context.shadowBlur = 6;
    context.fillRect(-carLengthPx / 2 - 2, -carWidthPx / 2, 2, 3);
    context.fillRect(-carLengthPx / 2 - 2, carWidthPx / 2 - 3, 2, 3);
    context.shadowBlur = 0;
  }

  // Car Body
  context.fillStyle = car.color || "#38bdf8";
  context.beginPath();
  context.roundRect(-carLengthPx / 2, -carWidthPx / 2, carLengthPx, carWidthPx, 3);
  context.fill();

  // Roof / Windshield
  context.fillStyle = "#0f172a";
  context.fillRect(-carLengthPx / 6, -carWidthPx / 2 + 1.5, carLengthPx / 2.2, carWidthPx - 3);

  // Headlights
  context.fillStyle = "rgba(254, 240, 138, 0.9)";
  context.fillRect(carLengthPx / 2 - 1, -carWidthPx / 2 + 1, 2, 2.5);
  context.fillRect(carLengthPx / 2 - 1, carWidthPx / 2 - 3.5, 2, 2.5);

  context.restore();
}

// -------------------------------------------------------------
// Live Mini Charts (HTML5 Canvas 2D)
// -------------------------------------------------------------
function renderMiniChart(context, canvas, data, strokeColor, label) {
  const w = canvas.width;
  const h = canvas.height;

  context.clearRect(0, 0, w, h);

  if (!data || data.length < 2) {
    context.fillStyle = "#64748b";
    context.font = "11px Inter, sans-serif";
    context.fillText("Awaiting telemetry...", 14, h / 2);
    return;
  }

  const minVal = Math.min(...data);
  const maxVal = Math.max(...data);
  const range = maxVal - minVal || 1;

  // Grid line
  context.strokeStyle = "rgba(255, 255, 255, 0.05)";
  context.lineWidth = 1;
  context.beginPath();
  context.moveTo(0, h / 2);
  context.lineTo(w, h / 2);
  context.stroke();

  // Gradient fill under curve
  const grad = context.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, strokeColor.replace(")", ", 0.25)").replace("rgb", "rgba"));
  grad.addColorStop(1, "transparent");

  context.beginPath();
  data.forEach((val, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - 10 - ((val - minVal) / range) * (h - 20);
    if (i === 0) context.moveTo(x, y);
    else context.lineTo(x, y);
  });

  // Stroke line
  context.strokeStyle = strokeColor;
  context.lineWidth = 2;
  context.stroke();

  // Fill area
  context.lineTo(w, h);
  context.lineTo(0, h);
  context.closePath();
  context.fillStyle = grad;
  context.fill();

  // Current value label
  const lastVal = data[data.length - 1];
  context.fillStyle = "#f8fafc";
  context.font = "bold 11px JetBrains Mono, monospace";
  context.fillText(`${lastVal}`, w - 38, 18);
}

// -------------------------------------------------------------
// Event Handlers & Playback Loop
// -------------------------------------------------------------
btnPlayPause.addEventListener("click", () => {
  isPlaying = !isPlaying;
  if (isPlaying) {
    btnPlayPause.classList.remove("btn-primary");
    btnPlayPause.classList.add("btn-secondary");
    playIcon.textContent = "⏸";
    playText.textContent = "Pause";
    startLoop();
  } else {
    btnPlayPause.classList.remove("btn-secondary");
    btnPlayPause.classList.add("btn-primary");
    playIcon.textContent = "▶";
    playText.textContent = "Play";
    stopLoop();
  }
});

btnStep.addEventListener("click", () => {
  stepSimulation();
});

btnReset.addEventListener("click", () => {
  resetSimulation();
});

speedSelect.addEventListener("change", (e) => {
  playbackSpeed = parseInt(e.target.value, 10);
  if (isPlaying) {
    stopLoop();
    startLoop();
  }
});

rushHourToggle.addEventListener("change", () => {
  resetSimulation();
});

ctrlTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const mode = tab.dataset.mode;
    setControllerMode(mode);
  });
});

btnManualNS.addEventListener("click", () => {
  stepSimulation(0); // NS Green
});

btnManualEW.addEventListener("click", () => {
  stepSimulation(1); // EW Green
});

function startLoop() {
  const intervalMs = Math.max(25, Math.floor(1000 / playbackSpeed));
  timerId = setInterval(() => {
    stepSimulation();
  }, intervalMs);
}

function stopLoop() {
  if (timerId) {
    clearInterval(timerId);
    timerId = null;
  }
}

// Initial initialization
fetchState();
