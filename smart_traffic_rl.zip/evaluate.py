"""
Comparative Evaluation Benchmark: RL Agent vs Fixed-Time vs Vehicle-Actuated.
Generates statistical metrics, comparative summary tables, and visualization charts.
"""

import argparse
import json
import os
import sys
from typing import Dict, List
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for headless plotting
import matplotlib.pyplot as plt
import numpy as np

# Ensure project root in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from configs.config import IntersectionConfig, BaselineConfig
from env.traffic_env import TrafficIntersectionEnv
from agents.dqn_agent import DQNAgent
from baselines.fixed_time import FixedTimeController
from baselines.actuated import ActuatedController


def run_benchmark(
    episodes: int = 5,
    steps_per_episode: int = 400,
    model_path: str = "checkpoints/dqn_traffic_best.pt",
    output_dir: str = "results",
):
    os.makedirs(output_dir, exist_ok=True)
    cfg = IntersectionConfig()

    # Initialize controllers
    controllers = {}

    # 1. DQN Agent
    dqn_available = False
    if os.path.exists(model_path):
        agent = DQNAgent(state_dim=15, action_dim=2)
        agent.load(model_path, evaluate_only=True)
        controllers["RL (DQN)"] = agent
        dqn_available = True
    else:
        print(f"[Warning] Checkpoint {model_path} not found. Running untrained/heuristic DQN fallback.")
        agent = DQNAgent(state_dim=15, action_dim=2)
        agent.epsilon = 0.05
        controllers["RL (DQN)"] = agent

    # 2. Fixed-Time Baseline
    controllers["Fixed-Time"] = FixedTimeController(BaselineConfig())

    # 3. Vehicle-Actuated Baseline
    controllers["Actuated"] = ActuatedController(BaselineConfig())

    metrics = {name: {
        "delays": [],
        "waiting_times": [],
        "throughputs": [],
        "avg_queues": [],
        "rewards": [],
        "queue_trajectories": [],
    } for name in controllers}

    print("=" * 70)
    print(" Running Traffic Signal Controller Benchmark")
    print(f" Episodes: {episodes} | Steps: {steps_per_episode}s | Models: {list(controllers.keys())}")
    print("=" * 70)

    for ep in range(episodes):
        seed = 42 + ep * 137

        for name, ctrl in controllers.items():
            env = TrafficIntersectionEnv(config=cfg, max_steps=steps_per_episode, seed=seed)
            if hasattr(ctrl, "reset"):
                ctrl.reset()

            obs, info = env.reset(seed=seed)
            done = False
            truncated = False
            ep_reward = 0.0
            step_queues = []

            while not (done or truncated):
                if isinstance(ctrl, DQNAgent):
                    action = ctrl.select_action(obs, deterministic=True)
                elif isinstance(ctrl, ActuatedController):
                    action = ctrl.select_action(obs, info)
                else:  # FixedTimeController
                    action = ctrl.select_action()

                obs, reward, done, truncated, info = env.step(action)
                ep_reward += reward
                step_queues.append(info["total_queue"])

            metrics[name]["delays"].append(info["avg_delay"])
            metrics[name]["waiting_times"].append(info["total_waiting_time"])
            metrics[name]["throughputs"].append(info["cleared_vehicles"])
            metrics[name]["avg_queues"].append(float(np.mean(step_queues)))
            metrics[name]["rewards"].append(ep_reward)
            if ep == 0:  # store episode 0 trajectory for plotting
                metrics[name]["queue_trajectories"] = step_queues

    # Summarize results
    summary = {}
    print(f"\n{'Controller':<18} | {'Avg Delay (s)':<14} | {'Throughput (veh)':<18} | {'Avg Queue':<12} | {'Reward':<10}")
    print("-" * 78)

    for name in controllers:
        summary[name] = {
            "mean_delay_sec": round(float(np.mean(metrics[name]["delays"])), 2),
            "std_delay_sec": round(float(np.std(metrics[name]["delays"])), 2),
            "mean_throughput": round(float(np.mean(metrics[name]["throughputs"])), 1),
            "mean_waiting_time": round(float(np.mean(metrics[name]["waiting_times"])), 1),
            "mean_queue": round(float(np.mean(metrics[name]["avg_queues"])), 2),
            "mean_reward": round(float(np.mean(metrics[name]["rewards"])), 1),
        }
        print(f"{name:<18} | "
              f"{summary[name]['mean_delay_sec']:>6.2f} ± {summary[name]['std_delay_sec']:<4.2f} | "
              f"{summary[name]['mean_throughput']:>8.1f} vehicles | "
              f"{summary[name]['mean_queue']:>7.2f} cars | "
              f"{summary[name]['mean_reward']:>8.1f}")
    print("-" * 78)

    # Save summary JSON
    summary_file = os.path.join(output_dir, "evaluation_summary.json")
    with open(summary_file, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n[+] Saved numerical evaluation results to: {summary_file}")

    # Generate Comparative Visualizations
    plot_benchmark_results(summary, metrics, output_dir)


def plot_benchmark_results(summary: dict, metrics: dict, output_dir: str):
    """Generates clean publication-quality comparison charts."""
    names = list(summary.keys())
    palette = ["#10b981", "#3b82f6", "#f59e0b"]  # Emerald, Blue, Amber

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")

    # 1. Average Delay
    delays = [summary[n]["mean_delay_sec"] for n in names]
    errs = [summary[n]["std_delay_sec"] for n in names]
    axes[0, 0].bar(names, delays, yerr=errs, capsize=5, color=palette, alpha=0.85, edgecolor="#1e293b", width=0.5)
    axes[0, 0].set_title("Average Vehicle Delay (Lower is Better)", fontsize=12, fontweight="bold", pad=10)
    axes[0, 0].set_ylabel("Delay (seconds)")
    for i, v in enumerate(delays):
        axes[0, 0].text(i, v + max(errs) * 0.2 + 0.5, f"{v:.1f}s", ha="center", fontweight="semibold")

    # 2. Total Throughput
    throughputs = [summary[n]["mean_throughput"] for n in names]
    axes[0, 1].bar(names, throughputs, color=palette, alpha=0.85, edgecolor="#1e293b", width=0.5)
    axes[0, 1].set_title("Total Vehicles Cleared (Higher is Better)", fontsize=12, fontweight="bold", pad=10)
    axes[0, 1].set_ylabel("Vehicles / Episode")
    for i, v in enumerate(throughputs):
        axes[0, 1].text(i, v + 1.0, f"{int(v)}", ha="center", fontweight="semibold")

    # 3. Average Queue Length
    queues = [summary[n]["mean_queue"] for n in names]
    axes[1, 0].bar(names, queues, color=palette, alpha=0.85, edgecolor="#1e293b", width=0.5)
    axes[1, 0].set_title("Average Queue Length (Lower is Better)", fontsize=12, fontweight="bold", pad=10)
    axes[1, 0].set_ylabel("Vehicles Stopped")
    for i, v in enumerate(queues):
        axes[1, 0].text(i, v + 0.3, f"{v:.1f}", ha="center", fontweight="semibold")

    # 4. Total Cumulative Reward
    rewards = [summary[n]["mean_reward"] for n in names]
    axes[1, 1].bar(names, rewards, color=palette, alpha=0.85, edgecolor="#1e293b", width=0.5)
    axes[1, 1].set_title("Cumulative RL Reward (Higher is Better)", fontsize=12, fontweight="bold", pad=10)
    axes[1, 1].set_ylabel("Reward")
    for i, v in enumerate(rewards):
        axes[1, 1].text(i, v - 15.0 if v < 0 else v + 5.0, f"{v:.0f}", ha="center", fontweight="semibold")

    fig.suptitle("Traffic Signal Performance: RL Agent vs Traditional Baselines", fontsize=15, fontweight="bold", y=0.98)
    plt.tight_layout()
    chart_path = os.path.join(output_dir, "comparison_metrics.png")
    fig.savefig(chart_path, dpi=200)
    plt.close(fig)
    print(f"[+] Saved metrics chart to: {chart_path}")

    # Plot Queue Evolution over Time
    fig2, ax2 = plt.subplots(figsize=(11, 4.5))
    for idx, name in enumerate(names):
        traj = metrics[name]["queue_trajectories"]
        if traj:
            # Smooth with moving average for clean visualization
            window = 10
            smoothed = np.convolve(traj, np.ones(window)/window, mode='valid')
            ax2.plot(smoothed, label=name, color=palette[idx % len(palette)], linewidth=2.2)

    ax2.set_title("Queue Length Dynamics Across Simulation (Episode 1)", fontsize=12, fontweight="bold")
    ax2.set_xlabel("Simulation Time (Seconds)")
    ax2.set_ylabel("Total Queue (Vehicles)")
    ax2.legend(frameon=True, facecolor="white", loc="upper right")
    ax2.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    traj_path = os.path.join(output_dir, "queue_dynamics.png")
    fig2.savefig(traj_path, dpi=200)
    plt.close(fig2)
    print(f"[+] Saved queue dynamics plot to: {traj_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate Traffic Signal Controllers")
    parser.add_argument("--episodes", type=int, default=5, help="Number of benchmark episodes")
    parser.add_argument("--steps", type=int, default=400, help="Steps per benchmark episode")
    parser.add_argument("--model", type=str, default="checkpoints/dqn_traffic_best.pt", help="Path to trained model")
    parser.add_argument("--out", type=str, default="results", help="Output directory")
    args = parser.parse_args()

    run_benchmark(
        episodes=args.episodes,
        steps_per_episode=args.steps,
        model_path=args.model,
        output_dir=args.out,
    )
