"""
Deep Q-Network (DQN / Double Dueling DQN) Agent for Smart Traffic Signal Control.
"""

import os
from typing import Optional, Tuple
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from configs.config import DQNConfig
from agents.networks import DuelingDQN, StandardDQN
from agents.replay_buffer import ReplayBuffer


class DQNAgent:
    """
    Double Dueling DQN Agent with Experience Replay and Soft/Polyak Target Updates.
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        config: Optional[DQNConfig] = None,
        use_dueling: bool = True,
        device: Optional[str] = None,
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.cfg = config or DQNConfig()
        
        # Select computing device (GPU if available, else CPU)
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        # Networks
        net_cls = DuelingDQN if use_dueling else StandardDQN
        self.policy_net = net_cls(state_dim, action_dim, self.cfg.hidden_dim).to(self.device)
        self.target_net = net_cls(state_dim, action_dim, self.cfg.hidden_dim).to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        # Optimizer & Loss
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=self.cfg.learning_rate)
        self.criterion = nn.SmoothL1Loss()  # Huber Loss for training stability

        # Experience Replay
        self.memory = ReplayBuffer(state_dim, capacity=self.cfg.buffer_capacity, device=str(self.device))

        # Exploration parameters
        self.epsilon = self.cfg.epsilon_start
        self.total_steps = 0
        self.train_step_count = 0

    def select_action(self, state: np.ndarray, deterministic: bool = False) -> int:
        """Selects action via epsilon-greedy policy or greedy inference."""
        if not deterministic and np.random.random() < self.epsilon:
            return int(np.random.randint(0, self.action_dim))

        state_tensor = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q_values = self.policy_net(state_tensor)
            action = q_values.argmax(dim=-1).item()
        return int(action)

    def step(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ) -> Optional[float]:
        """
        Stores transition, decays epsilon, and performs optimization step if ready.
        Returns loss if optimization occurred, else None.
        """
        self.total_steps += 1
        self.memory.push(state, action, reward, next_state, done)

        loss_val = None
        if len(self.memory) >= self.cfg.warmup_steps and self.total_steps % self.cfg.train_freq == 0:
            loss_val = self.train_step()

        # Decay exploration rate
        if self.epsilon > self.cfg.epsilon_min:
            self.epsilon = max(self.cfg.epsilon_min, self.epsilon * self.cfg.epsilon_decay)

        return loss_val

    def train_step(self) -> float:
        """Samples a batch from memory and updates Q-network using Double DQN."""
        states, actions, rewards, next_states, dones = self.memory.sample(self.cfg.batch_size)

        # Current Q estimates
        current_q = self.policy_net(states).gather(1, actions)

        # Double DQN Target:
        # 1. Action selection using policy network
        with torch.no_grad():
            next_actions = self.policy_net(next_states).argmax(dim=-1, keepdim=True)
            # 2. Action evaluation using target network
            target_next_q = self.target_net(next_states).gather(1, next_actions)
            expected_q = rewards + (1.0 - dones) * (self.cfg.gamma * target_next_q)

        # Loss calculation
        loss = self.criterion(current_q, expected_q)

        # Gradient Descent
        self.optimizer.zero_grad()
        loss.backward()
        # Gradient clipping to prevent exploding gradients
        nn.utils.clip_grad_norm_(self.policy_net.parameters(), max_norm=10.0)
        self.optimizer.step()

        # Target network soft update (Polyak averaging)
        self.soft_update_target(tau=self.cfg.tau)

        self.train_step_count += 1
        return float(loss.item())

    def soft_update_target(self, tau: float):
        """Soft update target network weights: theta_target = tau * theta_policy + (1 - tau) * theta_target."""
        for target_param, policy_param in zip(self.target_net.parameters(), self.policy_net.parameters()):
            target_param.data.copy_(tau * policy_param.data + (1.0 - tau) * target_param.data)

    def save(self, filepath: str):
        """Saves model weights and training state to file."""
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        checkpoint = {
            "policy_state_dict": self.policy_net.state_dict(),
            "target_state_dict": self.target_net.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "epsilon": self.epsilon,
            "total_steps": self.total_steps,
            "train_step_count": self.train_step_count,
        }
        torch.save(checkpoint, filepath)

    def load(self, filepath: str, evaluate_only: bool = True):
        """Loads model weights from checkpoint."""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Checkpoint not found at {filepath}")

        checkpoint = torch.load(filepath, map_location=self.device, weights_only=True)
        self.policy_net.load_state_dict(checkpoint["policy_state_dict"])
        self.target_net.load_state_dict(checkpoint["target_state_dict"])

        if not evaluate_only and "optimizer_state_dict" in checkpoint:
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
            self.epsilon = checkpoint.get("epsilon", self.cfg.epsilon_min)
            self.total_steps = checkpoint.get("total_steps", 0)

        if evaluate_only:
            self.policy_net.eval()
            self.epsilon = 0.0
