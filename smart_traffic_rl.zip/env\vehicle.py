"""
Vehicle kinematic model and car-following logic for traffic intersection simulation.
"""

from typing import Optional


class Vehicle:
    """
    Represents an individual vehicle approaching or traversing an intersection.
    Uses Intelligent Driver Model (IDM) inspired kinematics.
    """
    def __init__(
        self,
        vehicle_id: str,
        origin: str,              # 'N', 'S', 'E', 'W'
        lane_idx: int,
        arm_length: float = 200.0,
        desired_speed: float = 13.89,  # ~50 km/h
        length: float = 4.5,
        min_gap: float = 2.0,
        max_accel: float = 2.5,
        max_decel: float = 4.5,
    ):
        self.id = vehicle_id
        self.origin = origin
        self.lane_idx = lane_idx
        self.arm_length = arm_length
        self.desired_speed = desired_speed
        self.length = length
        self.min_gap = min_gap
        self.max_accel = max_accel
        self.max_decel = max_decel

        # Kinematic state
        # position = 0 is spawn point; position = arm_length is the stop line; position > arm_length is cleared
        self.position: float = 0.0
        self.speed: float = desired_speed * 0.8  # enters at near desired speed
        self.acceleration: float = 0.0

        # Performance tracking metrics
        self.time_in_system: float = 0.0
        self.waiting_time: float = 0.0          # time spent stopped (v < 0.5 m/s)
        self.delay: float = 0.0                 # accumulated delay compared to free-flow
        self.cleared: bool = False              # crossed the intersection
        self.color: str = self._assign_color()

    def _assign_color(self) -> str:
        palette = ["#38bdf8", "#818cf8", "#c084fc", "#f472b6", "#fb7185", "#34d399", "#fbbf24"]
        return palette[hash(self.id) % len(palette)]

    @property
    def is_stopped(self) -> bool:
        """Vehicle is considered in queue / stopped if speed is below 0.5 m/s."""
        return self.speed < 0.5 and not self.cleared

    @property
    def distance_to_stop_line(self) -> float:
        """Distance from current front bumper to intersection stop line."""
        return max(0.0, self.arm_length - self.position)

    def update_motion(
        self,
        dt: float,
        lead_vehicle: Optional["Vehicle"],
        signal_state: str,  # 'GREEN', 'YELLOW', 'RED'
    ):
        """
        Updates speed, position, waiting time, and delay using safe car-following.
        """
        self.time_in_system += dt

        # Ideal free-flow distance covered in dt
        free_flow_dist = self.desired_speed * dt

        # Target stopping distance constraint
        effective_lead_gap = float("inf")
        relative_speed = 0.0

        # 1. Lead vehicle constraint
        if lead_vehicle is not None:
            gap = (lead_vehicle.position - lead_vehicle.length) - self.position
            effective_lead_gap = max(0.01, gap)
            relative_speed = self.speed - lead_vehicle.speed

        # 2. Traffic Signal constraint
        # If signal is RED or YELLOW and vehicle has not crossed the stop line
        if not self.cleared and self.position <= self.arm_length:
            dist_to_line = self.distance_to_stop_line
            # Can vehicle comfortably stop before the line on yellow?
            stopping_distance = (self.speed ** 2) / (2.0 * self.max_decel + 1e-6)

            if signal_state == 'RED':
                gap_to_line = max(0.01, dist_to_line)
                if gap_to_line < effective_lead_gap:
                    effective_lead_gap = gap_to_line
                    relative_speed = self.speed - 0.0

            elif signal_state == 'YELLOW':
                # Dilemma zone handling: if too close to stop safely, proceed; else stop
                if dist_to_line > stopping_distance + 2.0:
                    gap_to_line = max(0.01, dist_to_line)
                    if gap_to_line < effective_lead_gap:
                        effective_lead_gap = gap_to_line
                        relative_speed = self.speed - 0.0

        # IDM Acceleration computation
        # a = a_max * [ 1 - (v / v_0)^4 - (s*(v, delta_v) / s)^2 ]
        desired_headway = 1.5  # seconds
        s_star = self.min_gap + max(0.0, self.speed * desired_headway + (self.speed * relative_speed) / (2.0 * (self.max_accel * self.max_decel) ** 0.5 + 1e-6))
        
        accel_free = self.max_accel * (1.0 - (self.speed / (self.desired_speed + 1e-6)) ** 4)
        accel_brake = - self.max_accel * (s_star / (effective_lead_gap + 1e-6)) ** 2
        
        accel = accel_free + accel_brake
        self.acceleration = max(-self.max_decel, min(self.max_accel, accel))

        # Integrate velocity and position
        self.speed = max(0.0, min(self.desired_speed, self.speed + self.acceleration * dt))
        actual_dist = self.speed * dt
        self.position += actual_dist

        # Check if cleared intersection (passed stop line + intersection box ~20m)
        if self.position >= self.arm_length + 20.0:
            self.cleared = True

        # Track waiting time & delay
        if self.is_stopped:
            self.waiting_time += dt
        
        # Delay is difference between ideal distance and actual distance
        self.delay += max(0.0, (free_flow_dist - actual_dist) / (self.desired_speed + 1e-6))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "origin": self.origin,
            "lane_idx": self.lane_idx,
            "position": round(self.position, 2),
            "speed": round(self.speed, 2),
            "waiting_time": round(self.waiting_time, 2),
            "delay": round(self.delay, 2),
            "is_stopped": self.is_stopped,
            "cleared": self.cleared,
            "color": self.color,
        }
