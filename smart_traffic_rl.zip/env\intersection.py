"""
Intersection model representing road approaches, lane queues, and traffic signals.
"""

from typing import Dict, List, Tuple
import numpy as np
from env.vehicle import Vehicle
from configs.config import IntersectionConfig


class Intersection:
    """
    4-way Intersection managing traffic approaches (N, S, E, W),
    signals, lane queues, and vehicle propagation.
    """
    APPROACHES = ['N', 'S', 'E', 'W']
    
    # Major Green Phases
    PHASE_NS_GREEN = 0
    PHASE_NS_YELLOW = 1
    PHASE_EW_GREEN = 2
    PHASE_EW_YELLOW = 3

    def __init__(self, config: IntersectionConfig, intersection_id: str = "INT_01"):
        self.cfg = config
        self.id = intersection_id

        # Approach lanes containing list of active vehicles
        # structure: { 'N': { 0: [vehicles], 1: [vehicles] }, ... }
        self.approaches: Dict[str, Dict[int, List[Vehicle]]] = {
            app: {l: [] for l in range(self.cfg.lanes_per_approach)}
            for app in self.APPROACHES
        }

        # Signal state
        self.current_phase: int = self.PHASE_NS_GREEN
        self.phase_elapsed_time: float = 0.0
        self.is_transitioning: bool = False
        self.transition_time_remaining: float = 0.0
        self.target_phase: int = self.PHASE_NS_GREEN

        # Cumulative / Step metrics
        self.vehicles_generated_count: int = 0
        self.vehicles_cleared_count: int = 0
        self.step_cleared_count: int = 0
        self.cumulative_delay: float = 0.0
        self.cumulative_waiting_time: float = 0.0

        # Departure history for evaluation
        self.cleared_delays: List[float] = []

    def reset(self):
        """Resets the intersection to initial state."""
        self.approaches = {
            app: {l: [] for l in range(self.cfg.lanes_per_approach)}
            for app in self.APPROACHES
        }
        self.current_phase = self.PHASE_NS_GREEN
        self.phase_elapsed_time = 0.0
        self.is_transitioning = False
        self.transition_time_remaining = 0.0
        self.target_phase = self.PHASE_NS_GREEN

        self.vehicles_generated_count = 0
        self.vehicles_cleared_count = 0
        self.step_cleared_count = 0
        self.cumulative_delay = 0.0
        self.cumulative_waiting_time = 0.0
        self.cleared_delays.clear()

    def get_signal_for_approach(self, approach: str) -> str:
        """Returns signal color ('GREEN', 'YELLOW', 'RED') for a given approach."""
        if self.current_phase == self.PHASE_NS_GREEN:
            return 'GREEN' if approach in ['N', 'S'] else 'RED'
        elif self.current_phase == self.PHASE_NS_YELLOW:
            return 'YELLOW' if approach in ['N', 'S'] else 'RED'
        elif self.current_phase == self.PHASE_EW_GREEN:
            return 'GREEN' if approach in ['E', 'W'] else 'RED'
        elif self.current_phase == self.PHASE_EW_YELLOW:
            return 'YELLOW' if approach in ['E', 'W'] else 'RED'
        return 'RED'

    def request_phase(self, desired_green_phase: int) -> bool:
        """
        Requests to switch to or maintain a green phase (0 for NS_GREEN, 2 for EW_GREEN).
        Returns True if a switch transition was initiated.
        """
        # If currently transitioning through yellow, cannot change target mid-transition
        if self.is_transitioning:
            return False

        if desired_green_phase not in [self.PHASE_NS_GREEN, self.PHASE_EW_GREEN]:
            return False

        # If already in the requested phase, just keep going
        if self.current_phase == desired_green_phase:
            return False

        # Respect minimum green time
        if self.phase_elapsed_time < self.cfg.min_green_time:
            return False

        # Initiate transition through yellow
        self.is_transitioning = True
        self.target_phase = desired_green_phase
        self.transition_time_remaining = self.cfg.yellow_time

        if self.current_phase == self.PHASE_NS_GREEN:
            self.current_phase = self.PHASE_NS_YELLOW
        elif self.current_phase == self.PHASE_EW_GREEN:
            self.current_phase = self.PHASE_EW_YELLOW

        self.phase_elapsed_time = 0.0
        return True

    def spawn_vehicles(self, rng: np.random.Generator):
        """Generates vehicles probabilistically at the start of approach roads."""
        for app in self.APPROACHES:
            rate = self.cfg.arrival_rate_ns if app in ['N', 'S'] else self.cfg.arrival_rate_ew
            
            # Rush hour burst check
            if rng.random() < self.cfg.burst_probability:
                rate *= self.cfg.burst_multiplier

            # Generate vehicle if random check succeeds
            if rng.random() < rate:
                lane = int(rng.integers(0, self.cfg.lanes_per_approach))
                existing_lane = self.approaches[app][lane]

                # Check if spawn area is clear (at least car_length + min_gap from road entrance)
                can_spawn = True
                if len(existing_lane) > 0:
                    tail_car = existing_lane[-1]
                    if tail_car.position < (self.cfg.car_length + self.cfg.min_gap):
                        can_spawn = False

                if can_spawn:
                    self.vehicles_generated_count += 1
                    car = Vehicle(
                        vehicle_id=f"{app}_{lane}_{self.vehicles_generated_count}",
                        origin=app,
                        lane_idx=lane,
                        arm_length=self.cfg.arm_length,
                        desired_speed=self.cfg.speed_limit,
                        length=self.cfg.car_length,
                        min_gap=self.cfg.min_gap,
                        max_accel=self.cfg.max_accel,
                        max_decel=self.cfg.max_decel,
                    )
                    existing_lane.append(car)

    def step_simulation(self, dt: float, rng: np.random.Generator):
        """Simulates one time step for signals and all approaching vehicles."""
        self.step_cleared_count = 0

        # Update signal timing and transitions
        self.phase_elapsed_time += dt
        if self.is_transitioning:
            self.transition_time_remaining -= dt
            if self.transition_time_remaining <= 0.0:
                self.current_phase = self.target_phase
                self.is_transitioning = False
                self.phase_elapsed_time = 0.0

        # Spawn new vehicles
        self.spawn_vehicles(rng)

        # Update vehicles across all approaches and lanes
        for app in self.APPROACHES:
            signal_state = self.get_signal_for_approach(app)
            for lane_idx in range(self.cfg.lanes_per_approach):
                lane_vehicles = self.approaches[app][lane_idx]
                surviving_vehicles = []

                for idx, car in enumerate(lane_vehicles):
                    lead = lane_vehicles[idx - 1] if idx > 0 else None
                    car.update_motion(dt=dt, lead_vehicle=lead, signal_state=signal_state)

                    if car.cleared:
                        self.vehicles_cleared_count += 1
                        self.step_cleared_count += 1
                        self.cumulative_delay += car.delay
                        self.cumulative_waiting_time += car.waiting_time
                        self.cleared_delays.append(car.delay)
                    else:
                        surviving_vehicles.append(car)

                self.approaches[app][lane_idx] = surviving_vehicles

    def get_queue_lengths(self) -> Dict[str, int]:
        """Returns number of stopped vehicles (speed < 0.5 m/s) per approach."""
        queues = {}
        for app in self.APPROACHES:
            count = sum(
                sum(1 for v in self.approaches[app][l] if v.is_stopped)
                for l in range(self.cfg.lanes_per_approach)
            )
            queues[app] = count
        return queues

    def get_waiting_times(self) -> Dict[str, float]:
        """Returns cumulative waiting time of vehicles currently on each approach."""
        wait_times = {}
        for app in self.APPROACHES:
            total_wait = sum(
                sum(v.waiting_time for v in self.approaches[app][l])
                for l in range(self.cfg.lanes_per_approach)
            )
            wait_times[app] = total_wait
        return wait_times

    def get_vehicle_counts(self) -> Dict[str, int]:
        """Returns total active vehicles per approach."""
        counts = {}
        for app in self.APPROACHES:
            counts[app] = sum(len(self.approaches[app][l]) for l in range(self.cfg.lanes_per_approach))
        return counts

    def get_average_speeds(self) -> Dict[str, float]:
        """Returns average vehicle speed per approach in m/s."""
        speeds = {}
        for app in self.APPROACHES:
            all_cars = [v for l in range(self.cfg.lanes_per_approach) for v in self.approaches[app][l]]
            if all_cars:
                speeds[app] = sum(v.speed for v in all_cars) / len(all_cars)
            else:
                speeds[app] = self.cfg.speed_limit
        return speeds

    def get_active_vehicles(self) -> List[Vehicle]:
        """Returns flat list of all active vehicles on the intersection."""
        vehicles = []
        for app in self.APPROACHES:
            for l in range(self.cfg.lanes_per_approach):
                vehicles.extend(self.approaches[app][l])
        return vehicles

    def to_dict(self) -> dict:
        """Full serialization for API and dashboard live stream."""
        return {
            "intersection_id": self.id,
            "current_phase": self.current_phase,
            "phase_name": {
                0: "NS_GREEN",
                1: "NS_YELLOW",
                2: "EW_GREEN",
                3: "EW_YELLOW",
            }.get(self.current_phase, "UNKNOWN"),
            "phase_elapsed_time": round(self.phase_elapsed_time, 1),
            "is_transitioning": self.is_transitioning,
            "transition_time_remaining": round(self.transition_time_remaining, 1),
            "signals": {app: self.get_signal_for_approach(app) for app in self.APPROACHES},
            "queue_lengths": self.get_queue_lengths(),
            "waiting_times": {k: round(v, 1) for k, v in self.get_waiting_times().items()},
            "vehicle_counts": self.get_vehicle_counts(),
            "throughput_total": self.vehicles_cleared_count,
            "step_cleared": self.step_cleared_count,
            "cumulative_delay": round(self.cumulative_delay, 1),
            "avg_cleared_delay": (
                round(float(np.mean(self.cleared_delays)), 2)
                if self.cleared_delays else 0.0
            ),
            "vehicles": [v.to_dict() for v in self.get_active_vehicles()],
        }
