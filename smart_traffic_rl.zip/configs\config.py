"""
Configuration module for the Smart Traffic Signal Control System.
Provides type-safe simulation, RL agent, and evaluation parameters.
"""

from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass
class IntersectionConfig:
    # Road geometry
    arm_length: float = 200.0          # meters per approach road
    lanes_per_approach: int = 2        # e.g., 2 incoming lanes per direction
    lane_width: float = 3.5            # meters
    speed_limit: float = 13.89         # ~50 km/h in m/s
    dt: float = 1.0                    # simulation time-step in seconds

    # Traffic signal phase configuration
    # Phases:
    # 0: North-South Green (NS_G), EW Red
    # 1: North-South Yellow (NS_Y), EW Red
    # 2: East-West Green (EW_G), NS Red
    # 3: East-West Yellow (EW_Y), NS Red
    min_green_time: int = 10           # minimum green duration (seconds)
    max_green_time: int = 60           # maximum green duration (seconds)
    yellow_time: int = 4               # yellow change interval (seconds)
    all_red_time: int = 1              # all-red clearance interval (seconds)

    # Traffic generation
    arrival_rate_ns: float = 0.25      # vehicle arrival probability per second (NS)
    arrival_rate_ew: float = 0.20      # vehicle arrival probability per second (EW)
    burst_probability: float = 0.05    # rush-hour burst probability
    burst_multiplier: float = 2.5      # multiplier during burst

    # Vehicle dynamics
    max_accel: float = 2.5             # m/s^2
    max_decel: float = 4.5             # m/s^2 (emergency/safe braking)
    car_length: float = 4.5            # meters
    min_gap: float = 2.0               # standstill buffer (meters)


@dataclass
class DQNConfig:
    # Neural Network
    hidden_dim: int = 128
    learning_rate: float = 5e-4
    gamma: float = 0.99                # discount factor
    tau: float = 0.005                 # soft target update factor
    
    # Exploration
    epsilon_start: float = 1.0
    epsilon_min: float = 0.02
    epsilon_decay: float = 0.995
    
    # Replay Buffer
    buffer_capacity: int = 50_000
    batch_size: int = 64
    warmup_steps: int = 500            # random steps before training begins
    train_freq: int = 4                # train agent every N steps
    target_update_freq: int = 200      # hard target update interval if tau not used


@dataclass
class TrainingConfig:
    total_episodes: int = 150
    max_steps_per_episode: int = 400   # 400 seconds simulated time per episode
    eval_freq: int = 20                # evaluate every N episodes
    eval_episodes: int = 5
    seed: int = 42
    save_dir: str = "checkpoints"


@dataclass
class BaselineConfig:
    # Fixed-Time Cycle
    fixed_green_ns: int = 30
    fixed_yellow_ns: int = 4
    fixed_green_ew: int = 30
    fixed_yellow_ew: int = 4

    # Actuated Controller
    actuated_min_green: int = 10
    actuated_max_green: int = 50
    actuated_gap_threshold: float = 3.0  # seconds gap without vehicles triggers change
