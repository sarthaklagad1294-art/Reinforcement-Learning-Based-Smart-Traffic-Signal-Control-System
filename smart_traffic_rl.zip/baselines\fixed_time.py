"""
Fixed-Time (Pre-timed) Traffic Signal Baseline Controller.
Cycles cyclically through pre-configured green and yellow intervals.
"""

from configs.config import BaselineConfig


class FixedTimeController:
    """
    Standard pre-timed controller.
    Alternates between North-South green and East-West green on fixed clock cycles.
    """

    def __init__(self, config: BaselineConfig = BaselineConfig()):
        self.cfg = config
        self.cycle_time = (
            self.cfg.fixed_green_ns + self.cfg.fixed_yellow_ns +
            self.cfg.fixed_green_ew + self.cfg.fixed_yellow_ew
        )
        self.elapsed_time = 0

    def reset(self):
        self.elapsed_time = 0

    def select_action(self, obs=None, info=None) -> int:
        """
        Determines target phase based on current point in cycle.
        Returns:
            0: North-South Green (Phase 0)
            1: East-West Green (Phase 2)
        """
        phase_in_cycle = self.elapsed_time % self.cycle_time
        self.elapsed_time += 1

        # First half of cycle: NS green + yellow
        ns_duration = self.cfg.fixed_green_ns + self.cfg.fixed_yellow_ns
        if phase_in_cycle < ns_duration:
            return 0  # NS Green
        else:
            return 1  # EW Green
