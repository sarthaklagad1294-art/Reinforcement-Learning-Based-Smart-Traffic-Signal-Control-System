"""
Experience Replay Buffer for Deep Q-Learning.
"""

from typing import Tuple
import numpy as np
import torch


class ReplayBuffer:
    """
    Fixed-size cyclic buffer to store experience transitions (s, a, r, s', done).
    """

    def __init__(self, state_dim: int, capacity: int = 50_000, device: str = "cpu"):
        self.capacity = capacity
        self.device = torch.device(device)
        self.ptr = 0
        self.size = 0

        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity,), dtype=np.int64)
        self.rewards = np.zeros((capacity,), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros((capacity,), dtype=np.float32)

    def push(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ):
        """Stores a transition tuple into the buffer."""
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_states[self.ptr] = next_state
        self.dones[self.ptr] = float(done)

        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Randomly samples a batch of transitions converted to PyTorch tensors."""
        indices = np.random.randint(0, self.size, size=batch_size)

        states_t = torch.as_tensor(self.states[indices], dtype=torch.float32, device=self.device)
        actions_t = torch.as_tensor(self.actions[indices], dtype=torch.int64, device=self.device).unsqueeze(1)
        rewards_t = torch.as_tensor(self.rewards[indices], dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states_t = torch.as_tensor(self.next_states[indices], dtype=torch.float32, device=self.device)
        dones_t = torch.as_tensor(self.dones[indices], dtype=torch.float32, device=self.device).unsqueeze(1)

        return states_t, actions_t, rewards_t, next_states_t, dones_t

    def __len__(self) -> int:
        return self.size
