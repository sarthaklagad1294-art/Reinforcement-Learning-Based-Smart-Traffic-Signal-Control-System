# Intelligent Traffic Signal Control using Deep Reinforcement Learning

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Gymnasium](https://img.shields.io/badge/Gymnasium-1.0+-green.svg)](https://gymnasium.farama.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-ee4c2c.svg)](https://pytorch.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg)](https://fastapi.tiangolo.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An end-to-end, modular, and autonomous **Reinforcement Learning-Based Smart Traffic Signal Control Platform**. Designed from first principles to simulate urban intersections, minimize vehicular delay and queues, and provide high-fidelity real-time telemetry via an interactive HTML5 Canvas web dashboard.

---

## Key Features

1. **Gymnasium-Compatible Traffic Simulation (`/env`)**:
   - Zero-dependency microscopic traffic simulation running out-of-the-box (no SUMO or heavy binary installations required).
   - Realistic Intelligent Driver Model (IDM) car-following kinematics, safe stopping distances, dilemma zone handling, and yellow clearance intervals.
   - Modular support for both single 4-way intersections (`TrafficIntersectionEnv`) and multi-intersection arterial corridors (`MultiIntersectionGridEnv`).
2. **Deep Reinforcement Learning Agent (`/agents`)**:
   - Double Dueling Deep Q-Network (Double Dueling DQN) implemented in PyTorch.
   - Separate Value $V(s)$ and Advantage $A(s, a)$ network streams to decouple state valuation from action advantages.
   - Experience Replay memory buffer with Polyak target network soft-updates ($\tau = 0.005$) and Huber loss stability.
3. **Traditional Baseline Controllers (`/baselines`)**:
   - **Fixed-Time Controller**: Pre-timed cyclic alternating phase control (e.g. 30s NS, 4s Yellow, 30s EW, 4s Yellow).
   - **Vehicle-Actuated Controller**: Dynamic demand-responsive controller using simulated induction loop presence detectors to execute gap-out and max-out switching logic.
4. **Interactive Real-Time Web Dashboard (`/dashboard`)**:
   - FastAPI REST backend streaming microscopic vehicle positions, phase states, and telemetry.
   - High-DPI HTML5 Canvas rendering engine featuring animated traffic lights with glowing LEDs, moving vehicles with brake lights/headlights, approach queues, and live charts.
   - Interactive live controller switcher: compare RL vs Actuated vs Fixed-Time vs Manual override in real-time.
5. **Comprehensive Comparative Benchmark Suite (`evaluate.py`)**:
   - Automated Monte Carlo evaluation across multiple test seeds.
   - Statistical performance comparison (Delay, Queue Length, Waiting Time, Throughput, Cumulative Reward).
   - Auto-generated publication-quality Matplotlib figures.

---

## RL Mathematical Formulation

### State Space $\mathcal{S} \in \mathbb{R}^{15}$
At time step $t$, the observation vector consists of:
- **Approach Queue Lengths ($4$)**: Normalized stopped vehicles on North, South, East, and West approaches.
- **Approach Waiting Times ($4$)**: Normalized cumulative seconds spent stopped on each approach.
- **Vehicle Counts ($4$)**: Total active vehicles on each approach road.
- **Current Phase ($1$)**: Active signal phase normalized ($0.0$ to $1.0$).
- **Elapsed Phase Time ($1$)**: Seconds current phase has been active normalized by $T_{\max}$.
- **Transition Status ($1$)**: Binary flag indicating whether the intersection is currently in a yellow clearance transition.

### Action Space $\mathcal{A}$
Discrete action selection:
- $a = 0$: Request **Phase 0 (North-South Green)**
- $a = 1$: Request **Phase 2 (East-West Green)**

*Safety Constraint*: Phase transitions automatically enforce minimum green time ($T_{\min} = 10\text{s}$), maximum green time ($T_{\max} = 60\text{s}$), and safe yellow clearance intervals ($T_{\text{yellow}} = 4\text{s}$).

### Reward Function $\mathcal{R}(s, a)$
The reward encourages high vehicular throughput while penalizing queue accumulation and phase instability:

$$R_t = - w_q \sum_{app} Q_{app} - w_w \sum_{app} W_{app} + w_{th} N_{\text{cleared}} - c_{\text{switch}} \cdot \mathbb{I}_{\text{switch}}$$

Where:
- $w_q = 0.20$: Queue penalty weight
- $w_w = 0.05$: Waiting time penalty weight
- $w_{th} = 3.00$: Throughput clearance bonus
- $c_{\text{switch}} = 0.50$: Transition penalty to avoid rapid flickering

---

## Directory Structure

```
smart_traffic_rl/
├── configs/
│   └── config.py              # Centralized dataclasses (Intersection, DQN, Baseline)
├── env/
│   ├── __init__.py
│   ├── vehicle.py             # IDM kinematic vehicle model & car-following
│   ├── intersection.py        # 4-way intersection geometry & signal logic
│   ├── traffic_env.py         # Gymnasium Environment implementation
│   └── grid_env.py            # Multi-intersection arterial corridor
├── agents/
│   ├── __init__.py
│   ├── networks.py            # Dueling DQN & Standard MLP PyTorch modules
│   ├── replay_buffer.py       # Experience replay buffer with tensor sampling
│   └── dqn_agent.py           # Double Dueling DQN agent
├── baselines/
│   ├── __init__.py
│   ├── fixed_time.py          # Fixed-time cyclic baseline
│   └── actuated.py            # Demand-responsive actuated baseline
├── dashboard/
│   ├── app.py                 # FastAPI backend server
│   └── static/
│       ├── index.html         # Modern dark-mode dashboard UI
│       ├── style.css          # Glassmorphic styles & animations
│       └── app.js             # Canvas rendering engine & telemetry loop
├── tests/
│   ├── test_env.py            # Gymnasium compliance & physics unit tests
│   ├── test_agent.py          # Replay buffer & neural network tests
│   ├── test_baselines.py      # Baseline controller tests
│   └── test_api.py            # FastAPI endpoint tests
├── checkpoints/               # Saved PyTorch model weights (.pt)
├── results/                   # Benchmark plots & JSON metrics
├── train.py                   # RL model training pipeline
├── evaluate.py                # Comparative evaluation & plotting runner
├── requirements.txt           # Project dependencies
└── README.md                  # Comprehensive documentation
```

---

## Getting Started

### 1. Installation
Clone or navigate to the workspace directory:
```bash
cd smart_traffic_rl
pip install -r requirements.txt
```

### 2. Run Automated Test Suite
Verify environment, agent, baselines, and API:
```bash
python -m pytest tests/ -v
```

### 3. Train the DQN Traffic Agent
Train a Double Dueling DQN agent on the intersection simulator:
```bash
python train.py --episodes 80 --steps 300 --eval-freq 20 --save-dir checkpoints
```
This saves:
- `checkpoints/dqn_traffic_best.pt` (Best checkpoint by evaluation reward)
- `checkpoints/dqn_traffic_latest.pt`
- `checkpoints/training_metrics.json`

### 4. Run Comparative Benchmark Evaluation
Benchmark the trained RL agent against traditional municipal controllers:
```bash
python evaluate.py --episodes 5 --steps 400 --model checkpoints/dqn_traffic_best.pt --out results
```
This generates:
- Statistical summary table in the terminal
- `results/evaluation_summary.json`
- `results/comparison_metrics.png` (Delay, Throughput, Queue, and Reward comparison)
- `results/queue_dynamics.png` (Time series queue evolution)

### 5. Launch the Interactive Web Dashboard
Start the local FastAPI visualization server:
```bash
python -m uvicorn dashboard.app:app --host 127.0.0.1 --port 8000 --reload
```
Open your browser to:
```
http://localhost:8000
```
- Click **Play** to start the microscopic simulation.
- Switch between **DQN Agent**, **Actuated**, **Fixed-Time**, or **Manual** controller modes in real-time.
- Toggle **Rush Hour Surge** to observe how the AI agent dynamically adapts to heavy congestion!

---

## License
MIT License. Built with ❤️ for intelligent, sustainable urban mobility.
