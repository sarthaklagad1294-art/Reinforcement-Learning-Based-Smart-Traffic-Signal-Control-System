"""
Training pipeline for Reinforcement Learning Traffic Signal Agent.
Trains Double Dueling DQN on TrafficIntersectionEnv and saves model checkpoints.
"""

import argparse
import json
import os
import sys
import time
from typing import Dict, List
import numpy as np

# Ensure project root in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from configs.config import IntersectionConfig, DQNConfig, TrainingConfig
from env.traffic_env import TrafficIntersectionEnv
from agents.dqn_agent import DQNAgent


def evaluate_agent(
    env: TrafficIntersectionEnv,
    agent: DQNAgent,
    num_episodes: int = 5,
) -> Dict[str, float]:
    """Evaluates agent deterministically across multiple episodes."""
    eval_rewards = []
    eval_cleared = []
    eval_delays = []
    eval_queues = []

    for ep in range(num_episodes):
        obs, info = env.reset(seed=1000 + ep)
        done = False
        truncated = False
        ep_reward = 0.0
        step_queues = []

        while not (done or truncated):
            action = agent.select_action(obs, deterministic=True)
            obs, reward, done, truncated, info = env.step(action)
            ep_reward += reward
            step_queues.append(info["total_queue"])

        eval_rewards.append(ep_reward)
        eval_cleared.append(info["cleared_vehicles"])
        eval_delays.append(info["avg_delay"])
        eval_queues.append(float(np.mean(step_queues)))

    return {
        "mean_reward": float(np.mean(eval_rewards)),
        "mean_cleared": float(np.mean(eval_cleared)),
        "mean_delay": float(np.mean(eval_delays)),
        "mean_queue": float(np.mean(eval_queues)),
    }


def train(
    total_episodes: int = 100,
    max_steps_per_episode: int = 400,
    eval_freq: int = 20,
    save_dir: str = "checkpoints",
    seed: int = 42,
):
    print("=" * 65)
    print("  Smart Traffic Signal RL Training (Double Dueling DQN)")
    print("=" * 65)
    
    np.random.seed(seed)
    os.makedirs(save_dir, exist_ok=True)

    env_cfg = IntersectionConfig()
    dqn_cfg = DQNConfig()

    env = TrafficIntersectionEnv(config=env_cfg, max_steps=max_steps_per_episode, seed=seed)
    eval_env = TrafficIntersectionEnv(config=env_cfg, max_steps=max_steps_per_episode, seed=seed + 100)

    agent = DQNAgent(
        state_dim=env.observation_space.shape[0],
        action_dim=int(env.action_space.n),
        config=dqn_cfg,
        use_dueling=True,
    )

    print(f"Device: {agent.device} | State Dim: {agent.state_dim} | Action Dim: {agent.action_dim}")
    print(f"Total Episodes: {total_episodes} | Steps Per Episode: {max_steps_per_episode}")
    print("-" * 65)

    history = {
        "episodes": [],
        "train_rewards": [],
        "train_cleared": [],
        "train_avg_queue": [],
        "losses": [],
        "eval_metrics": [],
    }

    best_eval_reward = -float("inf")
    start_time = time.time()

    for ep in range(1, total_episodes + 1):
        obs, info = env.reset(seed=seed + ep)
        done = False
        truncated = False
        ep_reward = 0.0
        ep_losses = []
        ep_queues = []

        while not (done or truncated):
            action = agent.select_action(obs, deterministic=False)
            next_obs, reward, done, truncated, info = env.step(action)

            loss = agent.step(obs, action, reward, next_obs, done or truncated)
            if loss is not None:
                ep_losses.append(loss)

            ep_queues.append(info["total_queue"])
            ep_reward += reward
            obs = next_obs

        avg_loss = float(np.mean(ep_losses)) if ep_losses else 0.0
        avg_queue = float(np.mean(ep_queues)) if ep_queues else 0.0

        history["episodes"].append(ep)
        history["train_rewards"].append(round(ep_reward, 2))
        history["train_cleared"].append(info["cleared_vehicles"])
        history["train_avg_queue"].append(round(avg_queue, 2))
        history["losses"].append(round(avg_loss, 4))

        if ep % 5 == 0 or ep == 1:
            print(
                f"Ep [{ep:03d}/{total_episodes:03d}] | "
                f"Reward: {ep_reward:7.1f} | "
                f"Cleared: {info['cleared_vehicles']:3d} | "
                f"Avg Queue: {avg_queue:4.1f} | "
                f"Eps: {agent.epsilon:4.3f} | "
                f"Loss: {avg_loss:6.4f}"
            )

        # Evaluation & Checkpoint saving
        if ep % eval_freq == 0 or ep == total_episodes:
            eval_res = evaluate_agent(eval_env, agent, num_episodes=4)
            eval_res["episode"] = ep
            history["eval_metrics"].append(eval_res)

            print(" " * 4 + f"--> [EVAL Ep {ep}] Mean Reward: {eval_res['mean_reward']:.1f} | "
                  f"Mean Delay: {eval_res['mean_delay']:.2f}s | "
                  f"Mean Cleared: {eval_res['mean_cleared']:.1f} | "
                  f"Mean Queue: {eval_res['mean_queue']:.1f}")

            # Save latest checkpoint
            agent.save(os.path.join(save_dir, "dqn_traffic_latest.pt"))

            # Save best checkpoint
            if eval_res["mean_reward"] > best_eval_reward:
                best_eval_reward = eval_res["mean_reward"]
                agent.save(os.path.join(save_dir, "dqn_traffic_best.pt"))
                print(f"    * New best model saved with eval reward: {best_eval_reward:.2f}")

    elapsed = time.time() - start_time
    print("-" * 65)
    print(f"Training completed in {elapsed:.1f}s | Best Eval Reward: {best_eval_reward:.2f}")

    # Save training metrics log
    metrics_path = os.path.join(save_dir, "training_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(history, f, indent=2)
    print(f"Saved training history to {metrics_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train RL Traffic Signal Controller")
    parser.add_argument("--episodes", type=int, default=80, help="Number of training episodes")
    parser.add_argument("--steps", type=int, default=300, help="Max steps per episode")
    parser.add_argument("--eval-freq", type=int, default=20, help="Evaluation frequency")
    parser.add_argument("--save-dir", type=str, default="checkpoints", help="Directory to save models")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    train(
        total_episodes=args.episodes,
        max_steps_per_episode=args.steps,
        eval_freq=args.eval_freq,
        save_dir=args.save_dir,
        seed=args.seed,
    )
