"""
Integration tests for FastAPI dashboard backend.
"""

from fastapi.testclient import TestClient
import pytest
from dashboard.app import app


@pytest.fixture
def client():
    return TestClient(app)


def test_get_dashboard_index(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "FLOW-RL" in response.text


def test_get_current_state(client):
    response = client.get("/api/state")
    assert response.status_code == 200
    data = response.json()
    assert "current_phase" in data
    assert "signals" in data
    assert "vehicles" in data
    assert "queue_lengths" in data


def test_step_simulation(client):
    response = client.post("/api/step", json={"steps": 2})
    assert response.status_code == 200
    data = response.json()
    assert data["step"] >= 2
    assert "reward" in data


def test_set_controller_mode(client):
    response = client.post("/api/set-controller", json={"mode": "Actuated"})
    assert response.status_code == 200
    assert response.json()["mode"] == "Actuated"

    # Reset back to RL
    response = client.post("/api/set-controller", json={"mode": "RL (DQN)"})
    assert response.status_code == 200
    assert response.json()["mode"] == "RL (DQN)"


def test_reset_simulation(client):
    response = client.post("/api/reset", json={"rush_hour": True})
    assert response.status_code == 200
    data = response.json()
    assert data["step"] == 0
