"""RL Agents module."""
from agents.networks import DuelingDQN, StandardDQN
from agents.replay_buffer import ReplayBuffer
from agents.dqn_agent import DQNAgent

__all__ = ["DuelingDQN", "StandardDQN", "ReplayBuffer", "DQNAgent"]
