"""
Vehicle-Actuated (Sensor-Driven) Traffic Signal Baseline Controller.
Dynamically extends green phase if vehicles are actively queued or approaching,
and switches phases when competing approaches accumulate waiting demand.
"""

from typing import Any, Dict, Optional, Union
import numpy as np
from configs.config import BaselineConfig


class ActuatedController:
    """
    Vehicle-actuated controller mimicking real-world loop detector logic.
    Observes queues and phase duration to make demand-responsive switching decisions.
    """

    def __init__(self, config: BaselineConfig = BaselineConfig()):
        self.cfg = config
        self.current_phase = 0
        self.elapsed_in_phase = 0

    def reset(self):
        self.current_phase = 0
        self.elapsed_in_phase = 0

    def select_action(self, obs: np.ndarray, info: Optional[Dict[str, Any]] = None) -> int:
        """
        Selects target phase using gap-out and max-out heuristics.
        obs: [norm_q_N, norm_q_S, norm_q_E, norm_q_W, ..., phase_norm, elapsed_norm, is_trans]
        """
        # Parse observation
        q_ns = obs[0] + obs[1]
        q_ew = obs[2] + obs[3]
        phase_raw = int(round(obs[12] * 3.0))
        is_transitioning = bool(obs[14] > 0.5)

        # Track elapsed time
        if phase_raw != self.current_phase and not is_transitioning:
            self.current_phase = phase_raw
            self.elapsed_in_phase = 0
        else:
            self.elapsed_in_phase += 1

        # NS is green (phase 0) or transitioning from NS (phase 1)
        if self.current_phase in [0, 1]:
            # If minimum green hasn't elapsed, keep green
            if self.elapsed_in_phase < self.cfg.actuated_min_green:
                return 0

            # Max green reached -> force change
            if self.elapsed_in_phase >= self.cfg.actuated_max_green:
                return 1

            # Gap out condition: EW has queued demand and NS queue is cleared
            if q_ew > 0 and q_ns <= 0.05:
                return 1

            # Imbalance condition: EW queue significantly exceeds NS
            if q_ew > q_ns * 1.5 and q_ew > 0.15:
                return 1

            return 0

        # EW is green (phase 2) or transitioning from EW (phase 3)
        else:
            if self.elapsed_in_phase < self.cfg.actuated_min_green:
                return 1

            if self.elapsed_in_phase >= self.cfg.actuated_max_green:
                return 0

            if q_ns > 0 and q_ew <= 0.05:
                return 0

            if q_ns > q_ew * 1.5 and q_ns > 0.15:
                return 0

            return 1
