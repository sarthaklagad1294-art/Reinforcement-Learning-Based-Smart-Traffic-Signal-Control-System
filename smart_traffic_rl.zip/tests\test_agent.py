"""
Unit tests for Reinforcement Learning Agent, Neural Networks, and Replay Buffer.
"""

import os
import tempfile
import numpy as np
import pytest
import torch

from configs.config import DQNConfig
from agents.networks import DuelingDQN, StandardDQN
from agents.replay_buffer import ReplayBuffer
from agents.dqn_agent import DQNAgent


def test_dueling_dqn_forward():
    batch_size = 8
    state_dim = 15
    action_dim = 2

    model = DuelingDQN(state_dim=state_dim, action_dim=action_dim, hidden_dim=64)
    x = torch.randn(batch_size, state_dim)
    q_vals = model(x)

    assert q_vals.shape == (batch_size, action_dim)
    assert not torch.isnan(q_vals).any()


def test_replay_buffer_operations():
    state_dim = 15
    buffer = ReplayBuffer(state_dim=state_dim, capacity=100, device="cpu")

    # Push transitions
    for i in range(25):
        s = np.random.randn(state_dim).astype(np.float32)
        a = i % 2
        r = float(i)
        s_next = np.random.randn(state_dim).astype(np.float32)
        d = (i == 24)
        buffer.push(s, a, r, s_next, d)

    assert len(buffer) == 25

    # Sample batch
    states, actions, rewards, next_states, dones = buffer.sample(batch_size=8)
    assert states.shape == (8, state_dim)
    assert actions.shape == (8, 1)
    assert rewards.shape == (8, 1)
    assert next_states.shape == (8, state_dim)
    assert dones.shape == (8, 1)


def test_dqn_agent_step_and_train():
    cfg = DQNConfig(
        warmup_steps=10,
        batch_size=4,
        train_freq=1,
        hidden_dim=32,
    )
    agent = DQNAgent(state_dim=15, action_dim=2, config=cfg, device="cpu")

    # Action selection
    s0 = np.random.randn(15).astype(np.float32)
    action = agent.select_action(s0, deterministic=True)
    assert action in [0, 1]

    # Populate warmup and trigger train step
    initial_loss = None
    for step_idx in range(15):
        s = np.random.randn(15).astype(np.float32)
        a = step_idx % 2
        r = 1.0
        s_next = np.random.randn(15).astype(np.float32)
        done = False
        loss = agent.step(s, a, r, s_next, done)
        if loss is not None and initial_loss is None:
            initial_loss = loss

    assert initial_loss is not None
    assert agent.total_steps == 15
    assert agent.epsilon < cfg.epsilon_start  # verified exploration decay


def test_dqn_agent_checkpoint_save_and_load():
    agent = DQNAgent(state_dim=15, action_dim=2, device="cpu")
    s = np.ones(15, dtype=np.float32)
    action_before = agent.select_action(s, deterministic=True)

    with tempfile.TemporaryDirectory() as tmp_dir:
        ckpt_path = os.path.join(tmp_dir, "test_model.pt")
        agent.save(ckpt_path)
        assert os.path.exists(ckpt_path)

        new_agent = DQNAgent(state_dim=15, action_dim=2, device="cpu")
        new_agent.load(ckpt_path, evaluate_only=True)
        action_after = new_agent.select_action(s, deterministic=True)

        assert action_before == action_after
