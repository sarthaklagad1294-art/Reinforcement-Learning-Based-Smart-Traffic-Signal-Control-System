"""
FastAPI Dashboard Backend for Smart Traffic Signal Control System.
Provides REST and state streaming endpoints for interactive web dashboard.
"""

import os
import sys
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

# Ensure project root in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from configs.config import IntersectionConfig, BaselineConfig
from env.traffic_env import TrafficIntersectionEnv
from agents.dqn_agent import DQNAgent
from baselines.fixed_time import FixedTimeController
from baselines.actuated import ActuatedController

app = FastAPI(title="Smart Traffic Signal RL Dashboard", version="1.0.0")

# Mount static folder
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# Global simulation state
class SimulationManager:
    def __init__(self):
        self.cfg = IntersectionConfig()
        self.env = TrafficIntersectionEnv(config=self.cfg, max_steps=1000)
        self.controller_mode = "RL (DQN)"
        
        # Load RL Agent
        self.agent = DQNAgent(state_dim=15, action_dim=2)
        model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "checkpoints", "dqn_traffic_best.pt")
        if os.path.exists(model_path):
            try:
                self.agent.load(model_path, evaluate_only=True)
                print(f"[SimManager] Successfully loaded trained DQN checkpoint: {model_path}")
            except Exception as e:
                print(f"[SimManager] Failed to load checkpoint: {e}")
        else:
            print("[SimManager] No checkpoint found yet. Using initialized DQN agent.")

        # Baseline controllers
        self.fixed_controller = FixedTimeController(BaselineConfig())
        self.actuated_controller = ActuatedController(BaselineConfig())

        # State storage
        self.obs, self.info = self.env.reset(seed=42)
        self.history = {
            "steps": [],
            "queues": [],
            "delays": [],
            "rewards": [],
            "throughput": [],
        }

    def reset(self, seed: Optional[int] = None, rush_hour: bool = False):
        if rush_hour:
            self.cfg.arrival_rate_ns = 0.40
            self.cfg.arrival_rate_ew = 0.35
            self.cfg.burst_probability = 0.15
        else:
            self.cfg.arrival_rate_ns = 0.25
            self.cfg.arrival_rate_ew = 0.20
            self.cfg.burst_probability = 0.05

        self.fixed_controller.reset()
        self.actuated_controller.reset()
        self.obs, self.info = self.env.reset(seed=seed)
        self.history = {
            "steps": [0],
            "queues": [self.info["total_queue"]],
            "delays": [self.info["avg_delay"]],
            "rewards": [0.0],
            "throughput": [0],
        }
        return self.get_state()

    def step(self, manual_action: Optional[int] = None):
        action = 0
        if manual_action is not None and self.controller_mode == "Manual":
            action = manual_action
        elif self.controller_mode == "RL (DQN)":
            action = self.agent.select_action(self.obs, deterministic=True)
        elif self.controller_mode == "Fixed-Time":
            action = self.fixed_controller.select_action()
        elif self.controller_mode == "Actuated":
            action = self.actuated_controller.select_action(self.obs, self.info)

        next_obs, reward, done, truncated, info = self.env.step(action)
        self.obs = next_obs
        self.info = info

        # Track history (keep last 120 points for smooth charts)
        self.history["steps"].append(self.env.current_step)
        self.history["queues"].append(info["total_queue"])
        self.history["delays"].append(round(info["avg_delay"], 2))
        self.history["rewards"].append(round(self.env.episode_rewards, 2))
        self.history["throughput"].append(info["cleared_vehicles"])

        if len(self.history["steps"]) > 120:
            for k in self.history:
                self.history[k].pop(0)

        state = self.get_state()
        state["last_action"] = action
        state["reward"] = round(reward, 2)
        state["done"] = bool(done or truncated)
        return state

    def get_state(self):
        render_dict = self.env.get_render_dict()
        render_dict["controller_mode"] = self.controller_mode
        render_dict["history"] = self.history
        return render_dict


sim = SimulationManager()


class SetControllerRequest(BaseModel):
    mode: str  # "RL (DQN)", "Fixed-Time", "Actuated", "Manual"


class StepRequest(BaseModel):
    steps: int = 1
    manual_action: Optional[int] = None


class ResetRequest(BaseModel):
    seed: Optional[int] = None
    rush_hour: bool = False


@app.get("/")
def get_dashboard_index():
    index_path = os.path.join(static_dir, "index.html")
    if not os.path.exists(index_path):
        raise HTTPException(status_code=404, detail="Dashboard UI not compiled yet")
    return FileResponse(index_path)


@app.get("/api/state")
def get_current_state():
    return sim.get_state()


@app.post("/api/step")
def step_simulation(req: StepRequest):
    last_state = None
    for _ in range(max(1, min(req.steps, 50))):
        last_state = sim.step(manual_action=req.manual_action)
    return last_state


@app.post("/api/reset")
def reset_simulation(req: ResetRequest):
    return sim.reset(seed=req.seed, rush_hour=req.rush_hour)


@app.post("/api/set-controller")
def set_controller(req: SetControllerRequest):
    valid_modes = ["RL (DQN)", "Fixed-Time", "Actuated", "Manual"]
    if req.mode not in valid_modes:
        raise HTTPException(status_code=400, detail=f"Mode must be one of {valid_modes}")
    sim.controller_mode = req.mode
    return {"status": "ok", "mode": sim.controller_mode}


@app.get("/api/benchmark-summary")
def get_benchmark_summary():
    results_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results", "evaluation_summary.json")
    if os.path.exists(results_file):
        with open(results_file, "r") as f:
            data = json.load(f)
        return data
    return {"message": "Run evaluate.py first to populate benchmark results"}
