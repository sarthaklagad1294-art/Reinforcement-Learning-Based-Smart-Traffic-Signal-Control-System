"""
Gymnasium-compatible Traffic Intersection Environment for Reinforcement Learning.
"""

from typing import Any, Dict, Optional, Tuple
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from configs.config import IntersectionConfig
from env.intersection import Intersection


class TrafficIntersectionEnv(gym.Env):
    """
    TrafficIntersectionEnv conforms to Gymnasium standard interface.
    
    Action Space:
        Discrete(2):
        0 = Target Phase 0 (North-South Green)
        1 = Target Phase 2 (East-West Green)

    Observation Space:
        Box(15,):
        - [0..3]: Normalized queue lengths (N, S, E, W)
        - [4..7]: Normalized total waiting times (N, S, E, W)
        - [8..11]: Normalized active vehicle counts (N, S, E, W)
        - [12]: Current phase (normalized: phase / 3.0)
        - [13]: Phase elapsed time (normalized: elapsed / max_green)
        - [14]: Is currently transitioning flag (0.0 or 1.0)
    """

    metadata = {"render_modes": ["human", "rgb_array", "ansi", "dict"]}

    def __init__(
        self,
        config: Optional[IntersectionConfig] = None,
        max_steps: int = 400,
        render_mode: Optional[str] = None,
        seed: Optional[int] = None,
    ):
        super().__init__()
        self.cfg = config or IntersectionConfig()
        self.max_steps = max_steps
        self.render_mode = render_mode
        self.current_step = 0

        # Random number generator
        self.np_random = np.random.default_rng(seed)

        # Intersection instance
        self.intersection = Intersection(self.cfg)

        # Define Gym Action Space: 0 for NS, 1 for EW
        self.action_space = spaces.Discrete(2)

        # Observation dimension: 4 + 4 + 4 + 3 = 15
        self.obs_dim = 15
        self.observation_space = spaces.Box(
            low=0.0,
            high=10.0,
            shape=(self.obs_dim,),
            dtype=np.float32,
        )

        # Performance history for episode
        self.episode_rewards: float = 0.0
        self.step_history: list = []

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Resets the environment for a new episode."""
        super().reset(seed=seed)
        if seed is not None:
            self.np_random = np.random.default_rng(seed)

        self.current_step = 0
        self.episode_rewards = 0.0
        self.step_history.clear()
        self.intersection.reset()

        obs = self._get_observation()
        info = self._get_info()
        return obs, info

    def _get_observation(self) -> np.ndarray:
        """Constructs normalized state representation."""
        max_capacity_per_arm = max(1.0, (self.cfg.arm_length / (self.cfg.car_length + self.cfg.min_gap)) * self.cfg.lanes_per_approach)

        queues = self.intersection.get_queue_lengths()
        waits = self.intersection.get_waiting_times()
        counts = self.intersection.get_vehicle_counts()

        norm_queues = [queues[app] / max_capacity_per_arm for app in ['N', 'S', 'E', 'W']]
        norm_waits = [min(5.0, waits[app] / 50.0) for app in ['N', 'S', 'E', 'W']]
        norm_counts = [counts[app] / max_capacity_per_arm for app in ['N', 'S', 'E', 'W']]

        phase_norm = self.intersection.current_phase / 3.0
        elapsed_norm = min(1.0, self.intersection.phase_elapsed_time / max(1.0, self.cfg.max_green_time))
        transition_flag = 1.0 if self.intersection.is_transitioning else 0.0

        obs = np.array(
            norm_queues + norm_waits + norm_counts + [phase_norm, elapsed_norm, transition_flag],
            dtype=np.float32,
        )
        return obs

    def _get_info(self) -> Dict[str, Any]:
        """Provides diagnostic and tracking info."""
        queues = self.intersection.get_queue_lengths()
        waits = self.intersection.get_waiting_times()
        return {
            "step": self.current_step,
            "total_queue": sum(queues.values()),
            "total_waiting_time": sum(waits.values()),
            "cleared_vehicles": self.intersection.vehicles_cleared_count,
            "step_cleared": self.intersection.step_cleared_count,
            "cumulative_delay": self.intersection.cumulative_delay,
            "avg_delay": (
                float(np.mean(self.intersection.cleared_delays))
                if self.intersection.cleared_delays else 0.0
            ),
            "current_phase": self.intersection.current_phase,
        }

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Executes one step in the environment.
        action: 0 (Target NS Green) or 1 (Target EW Green)
        """
        self.current_step += 1

        # Map action to target green phase:
        # 0 -> PHASE_NS_GREEN (0)
        # 1 -> PHASE_EW_GREEN (2)
        target_phase = self.intersection.PHASE_NS_GREEN if action == 0 else self.intersection.PHASE_EW_GREEN

        # Enforce max green time: if in a phase longer than max_green, force switch
        if (
            not self.intersection.is_transitioning
            and self.intersection.phase_elapsed_time >= self.cfg.max_green_time
        ):
            opposite_phase = (
                self.intersection.PHASE_EW_GREEN
                if self.intersection.current_phase == self.intersection.PHASE_NS_GREEN
                else self.intersection.PHASE_NS_GREEN
            )
            target_phase = opposite_phase

        # Attempt phase request
        switched = self.intersection.request_phase(target_phase)

        # Step physical simulation
        self.intersection.step_simulation(dt=self.cfg.dt, rng=self.np_random)

        # Reward Calculation:
        # 1. Negative reward proportional to queue length
        queues = self.intersection.get_queue_lengths()
        total_queue = sum(queues.values())
        r_queue = - 0.20 * total_queue

        # 2. Negative reward for accumulated waiting time
        waits = self.intersection.get_waiting_times()
        total_wait = sum(waits.values())
        r_wait = - 0.05 * total_wait

        # 3. Positive reward for vehicles cleared this step
        r_throughput = + 3.0 * self.intersection.step_cleared_count

        # 4. Small penalty for changing phase (discourage rapid switching churn)
        r_switch = - 0.5 if switched else 0.0

        reward = float(r_queue + r_wait + r_throughput + r_switch)
        self.episode_rewards += reward

        # Termination / Truncation
        terminated = False
        truncated = self.current_step >= self.max_steps

        obs = self._get_observation()
        info = self._get_info()

        return obs, reward, terminated, truncated, info

    def render(self):
        """Renders textual ANSI representation or returns state dict."""
        if self.render_mode in ["ansi", "human"] or self.render_mode is None:
            phase_str = {
                0: "NS: GREEN  | EW: RED",
                1: "NS: YELLOW | EW: RED",
                2: "NS: RED    | EW: GREEN",
                3: "NS: RED    | EW: YELLOW",
            }.get(self.intersection.current_phase, "UNKNOWN")
            queues = self.intersection.get_queue_lengths()
            text = (
                f"[Step {self.current_step:03d}] Phase: {phase_str} | "
                f"Queues -> N:{queues['N']} S:{queues['S']} E:{queues['E']} W:{queues['W']} | "
                f"Cleared: {self.intersection.vehicles_cleared_count}"
            )
            if self.render_mode == "human":
                print(text)
            return text
        elif self.render_mode == "dict":
            return self.get_render_dict()
        return None

    def get_render_dict(self) -> dict:
        """Full snapshot of intersection state for frontend visualization."""
        state = self.intersection.to_dict()
        state["step"] = self.current_step
        state["max_steps"] = self.max_steps
        state["episode_reward"] = round(self.episode_rewards, 2)
        return state
