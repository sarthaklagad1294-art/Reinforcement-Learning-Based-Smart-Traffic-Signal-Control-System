"""
Unit tests for Traffic Intersection Simulation Environments.
"""

import numpy as np
import pytest
from configs.config import IntersectionConfig
from env.vehicle import Vehicle
from env.intersection import Intersection
from env.traffic_env import TrafficIntersectionEnv
from env.grid_env import MultiIntersectionGridEnv


def test_vehicle_creation_and_motion():
    v = Vehicle(
        vehicle_id="N_0_1",
        origin="N",
        lane_idx=0,
        arm_length=200.0,
        desired_speed=14.0,
    )
    assert v.position == 0.0
    assert v.speed > 0.0
    assert not v.cleared
    assert not v.is_stopped

    # Motion update with GREEN signal
    v.update_motion(dt=1.0, lead_vehicle=None, signal_state="GREEN")
    assert v.position > 0.0
    assert v.time_in_system == 1.0


def test_vehicle_stopping_at_red_signal():
    v = Vehicle(
        vehicle_id="N_0_2",
        origin="N",
        lane_idx=0,
        arm_length=50.0,
        desired_speed=10.0,
    )
    v.position = 45.0  # close to stop line at 50m
    v.speed = 2.0

    # Motion update with RED signal -> should decelerate and stop
    for _ in range(10):
        v.update_motion(dt=1.0, lead_vehicle=None, signal_state="RED")

    assert v.position <= 50.0 + 1e-3  # should not cross red stop line
    assert v.is_stopped
    assert v.waiting_time > 0.0


def test_intersection_phase_transitions():
    cfg = IntersectionConfig(min_green_time=5, yellow_time=3)
    inter = Intersection(cfg)
    assert inter.current_phase == inter.PHASE_NS_GREEN
    assert not inter.is_transitioning

    # Request switch before min green elapsed -> should be rejected
    switched = inter.request_phase(inter.PHASE_EW_GREEN)
    assert not switched
    assert inter.current_phase == inter.PHASE_NS_GREEN

    # Advance time past min_green
    rng = np.random.default_rng(42)
    for _ in range(6):
        inter.step_simulation(dt=1.0, rng=rng)

    # Request switch now -> should start transition to yellow
    switched = inter.request_phase(inter.PHASE_EW_GREEN)
    assert switched
    assert inter.is_transitioning
    assert inter.current_phase == inter.PHASE_NS_YELLOW

    # Advance through yellow interval
    for _ in range(3):
        inter.step_simulation(dt=1.0, rng=rng)

    # Should now be in EW_GREEN
    assert not inter.is_transitioning
    assert inter.current_phase == inter.PHASE_EW_GREEN


def test_gym_traffic_env_interface():
    env = TrafficIntersectionEnv(max_steps=50, seed=42)
    obs, info = env.reset(seed=42)

    assert obs.shape == (15,)
    assert obs.dtype == np.float32
    assert "total_queue" in info
    assert "cleared_vehicles" in info

    # Step through simulation
    for step_i in range(10):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)

        assert obs.shape == (15,)
        assert isinstance(reward, float)
        assert not terminated
        assert not truncated
        assert info["step"] == step_i + 1

    # Render check
    ansi_str = env.render()
    assert isinstance(ansi_str, str)
    assert "Phase:" in ansi_str

    render_dict = env.get_render_dict()
    assert "vehicles" in render_dict
    assert "signals" in render_dict


def test_multi_intersection_grid_env():
    grid_env = MultiIntersectionGridEnv(num_intersections=2, max_steps=20, seed=42)
    obs, info = grid_env.reset(seed=42)

    assert obs.shape == (30,)  # 15 dims * 2 intersections
    actions = [0, 1]  # NS green for int 0, EW green for int 1
    obs, reward, terminated, truncated, info = grid_env.step(actions)

    assert obs.shape == (30,)
    assert isinstance(reward, float)
    assert "total_throughput" in info
