"""
Unit tests for Baseline Controllers (Fixed-Time & Vehicle-Actuated).
"""

import numpy as np
import pytest
from configs.config import BaselineConfig
from baselines.fixed_time import FixedTimeController
from baselines.actuated import ActuatedController


def test_fixed_time_controller_cycling():
    cfg = BaselineConfig(fixed_green_ns=10, fixed_yellow_ns=2, fixed_green_ew=10, fixed_yellow_ew=2)
    ctrl = FixedTimeController(cfg)
    assert ctrl.cycle_time == 24

    # First 12 seconds should be NS (0)
    for _ in range(12):
        action = ctrl.select_action()
        assert action == 0

    # Next 12 seconds should be EW (1)
    for _ in range(12):
        action = ctrl.select_action()
        assert action == 1

    # Cycle repeats: next should be NS (0)
    assert ctrl.select_action() == 0


def test_actuated_controller_responsiveness():
    cfg = BaselineConfig(actuated_min_green=5, actuated_max_green=20)
    ctrl = ActuatedController(cfg)

    # State where NS is green (phase 0), no EW queue
    obs_idle = np.zeros(15, dtype=np.float32)
    obs_idle[12] = 0.0  # phase 0

    # For first 5 steps, must keep green due to min_green
    for _ in range(5):
        assert ctrl.select_action(obs_idle) == 0

    # Now simulate sudden large queue on EW approaches (index 2 & 3)
    obs_demand_ew = np.zeros(15, dtype=np.float32)
    obs_demand_ew[2] = 0.5  # E queue
    obs_demand_ew[3] = 0.5  # W queue
    obs_demand_ew[12] = 0.0  # NS Green

    # Since min green has passed and EW queue is heavy while NS is empty,
    # controller should trigger phase switch to EW (action 1)
    action = ctrl.select_action(obs_demand_ew)
    assert action == 1
