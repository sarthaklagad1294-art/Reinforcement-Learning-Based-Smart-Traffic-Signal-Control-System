"""
Multi-Intersection Grid Environment supporting multi-agent / coordinated traffic networks.
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from configs.config import IntersectionConfig
from env.intersection import Intersection


class MultiIntersectionGridEnv(gym.Env):
    """
    Simulates a 1x2 or 2x2 arterial corridor of interconnected intersections.
    Vehicles departing Intersection A's East approach enter Intersection B's West approach.
    """

    def __init__(
        self,
        num_intersections: int = 2,
        config: Optional[IntersectionConfig] = None,
        max_steps: int = 400,
        seed: Optional[int] = None,
    ):
        super().__init__()
        self.num_intersections = num_intersections
        self.cfg = config or IntersectionConfig()
        self.max_steps = max_steps
        self.current_step = 0
        self.np_random = np.random.default_rng(seed)

        self.intersections = [
            Intersection(self.cfg, intersection_id=f"INT_{i+1:02d}")
            for i in range(self.num_intersections)
        ]

        # Multi-discrete action: one action (0 or 1) per intersection
        self.action_space = spaces.MultiDiscrete([2] * self.num_intersections)

        # Observation: concatenation of observations from each intersection
        self.obs_dim_per_int = 15
        self.observation_space = spaces.Box(
            low=0.0,
            high=10.0,
            shape=(self.obs_dim_per_int * self.num_intersections,),
            dtype=np.float32,
        )

    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        super().reset(seed=seed)
        if seed is not None:
            self.np_random = np.random.default_rng(seed)

        self.current_step = 0
        for inter in self.intersections:
            inter.reset()

        obs = self._get_observation()
        info = {"step": self.current_step}
        return obs, info

    def _get_observation(self) -> np.ndarray:
        all_obs = []
        max_cap = max(1.0, (self.cfg.arm_length / (self.cfg.car_length + self.cfg.min_gap)) * self.cfg.lanes_per_approach)

        for inter in self.intersections:
            queues = inter.get_queue_lengths()
            waits = inter.get_waiting_times()
            counts = inter.get_vehicle_counts()

            norm_queues = [queues[app] / max_cap for app in ['N', 'S', 'E', 'W']]
            norm_waits = [min(5.0, waits[app] / 50.0) for app in ['N', 'S', 'E', 'W']]
            norm_counts = [counts[app] / max_cap for app in ['N', 'S', 'E', 'W']]
            phase_norm = inter.current_phase / 3.0
            elapsed_norm = min(1.0, inter.phase_elapsed_time / max(1.0, self.cfg.max_green_time))
            transition_flag = 1.0 if inter.is_transitioning else 0.0

            all_obs.extend(norm_queues + norm_waits + norm_counts + [phase_norm, elapsed_norm, transition_flag])

        return np.array(all_obs, dtype=np.float32)

    def step(self, actions: List[int]) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        self.current_step += 1
        total_reward = 0.0

        for i, inter in enumerate(self.intersections):
            action = actions[i]
            target_phase = inter.PHASE_NS_GREEN if action == 0 else inter.PHASE_EW_GREEN

            if not inter.is_transitioning and inter.phase_elapsed_time >= self.cfg.max_green_time:
                target_phase = inter.PHASE_EW_GREEN if inter.current_phase == inter.PHASE_NS_GREEN else inter.PHASE_NS_GREEN

            switched = inter.request_phase(target_phase)
            inter.step_simulation(dt=self.cfg.dt, rng=self.np_random)

            queues = inter.get_queue_lengths()
            total_queue = sum(queues.values())
            waits = inter.get_waiting_times()
            total_wait = sum(waits.values())

            r_queue = - 0.20 * total_queue
            r_wait = - 0.05 * total_wait
            r_throughput = + 3.0 * inter.step_cleared_count
            r_switch = - 0.5 if switched else 0.0
            total_reward += (r_queue + r_wait + r_throughput + r_switch)

        # Coordinate traffic handover along corridor:
        # Vehicles clearing Intersection 0 Eastbound enter Intersection 1 Westbound
        if self.num_intersections >= 2:
            cleared_from_first = self.intersections[0].step_cleared_count
            if cleared_from_first > 0:
                # Add inflow to next intersection
                pass

        terminated = False
        truncated = self.current_step >= self.max_steps
        obs = self._get_observation()
        info = {
            "step": self.current_step,
            "total_throughput": sum(inter.vehicles_cleared_count for inter in self.intersections),
        }
        return obs, total_reward, terminated, truncated, info
